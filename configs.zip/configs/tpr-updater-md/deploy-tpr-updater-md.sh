#!/bin/bash

##################################### TPR Updater config-maps #####################################

# /thxcs-openshift/configs/tpr-updater-md

export SERVICE_NAME="tpr-md-updater"
oc delete configmap ${SERVICE_NAME}-common-props-config
oc delete configmap ${SERVICE_NAME}-registry-props-config
oc delete configmap ${SERVICE_NAME}-quartz-config

export SERVICE_NAME="tpr-md-updater"
export REPO="/c/zPrescribe/bitbucket_source/workspace/thxcs-openshift"
export LOCATION="configs/tpr-updater-md"
oc create configmap ${SERVICE_NAME}-common-props-config --from-file $REPO/$LOCATION/config/common
oc create configmap ${SERVICE_NAME}-registry-props-config --from-file $REPO/$LOCATION/config/eRxRegistryServiceWS
oc create configmap ${SERVICE_NAME}-quartz-config --from-file $REPO/$LOCATION/quartz

