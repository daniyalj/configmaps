#!/bin/bash

##################################### TPR Updater config-maps #####################################

export SERVICE_NAME="tpr-it-updater"
oc delete configmap ${SERVICE_NAME}-common-props-config
oc delete configmap ${SERVICE_NAME}-registry-props-config
oc delete configmap ${SERVICE_NAME}-quartz-config

# /thxcs-openshift/configs/tpr-updater-it
export SERVICE_NAME="tpr-it-updater"
export REPO="/c/zPrescribe/bitbucket_source/workspace/thxcs-openshift"
export LOCATION="configs/tpr-updater-it"
oc create configmap ${SERVICE_NAME}-common-props-config --from-file $REPO/$LOCATION/config/common
oc create configmap ${SERVICE_NAME}-registry-props-config --from-file $REPO/$LOCATION/config/eRxRegistryServiceWS
oc create configmap ${SERVICE_NAME}-quartz-config --from-file $REPO/$LOCATION/quartz
