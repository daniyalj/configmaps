#!/bin/bash

##################################### TPR config-maps #####################################
# IT
SERVICE_NAME="tpr-it-cache"

oc create configmap ${SERVICE_NAME}-common-props-config --from-file ./config/common
oc create configmap ${SERVICE_NAME}-registry-props-config --from-file ./config/eRxRegistryServiceWS
oc create configmap ${SERVICE_NAME}-tomcat-config --from-file ./tomcat/conf
