#!/bin/bash

##################################### TPR config-maps #####################################
# MD
# thxcs-openshift/configs/tpr-cache-md
SERVICE_NAME="tpr-md-cache"

oc delete configmap ${SERVICE_NAME}-common-props-config 
oc delete configmap ${SERVICE_NAME}-registry-props-config 
oc delete configmap ${SERVICE_NAME}-tomcat-config

oc create configmap ${SERVICE_NAME}-common-props-config --from-file ./config/common
oc create configmap ${SERVICE_NAME}-registry-props-config --from-file ./config/eRxRegistryServiceWS
oc create configmap ${SERVICE_NAME}-tomcat-config --from-file ./tomcat/conf
